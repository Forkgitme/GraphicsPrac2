Kevin Makatipu	4297024
Robin Sikkens	4228189

We did part 1 together.
2.1 to 2.3 and 4.1 were done by Kevin.
2.4 and 3 were done by Robin.

A point light was used for Lambertian shading.

Phong shading is used for the screenshots.
Blinn-Phong shading is turned on by default when
running the application, but you can switch
between Phong and Blinn-Phong with the P key.

The only bonus assignment we implemented is gamma
correction (4.1), which is implemented by letting
XNA draw everything to a texture first, and then
drawing that texture to the screen using
SpriteBatch with the gamma correction post-
processing effect. Gamma correction is enabled by
default.